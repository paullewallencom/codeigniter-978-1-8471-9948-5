<?php

$lang['error'] = "We have detected an error in your website: ";
$lang['database_unavailable'] = "Database unavailable";
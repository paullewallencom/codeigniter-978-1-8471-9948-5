<?php

$lang['error'] = "Hemos encontrado un problema en tu sitio web: ";
$lang['database_unavailable'] = "Base de datos no disponible";
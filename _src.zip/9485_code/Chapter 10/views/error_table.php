<?php

echo $table;
<img src="<?php echo base_url()."uploads/".$file; ?>"/>

<br/><br/>

<img src="<?php echo base_url()."uploads/t_".$file; ?>" />
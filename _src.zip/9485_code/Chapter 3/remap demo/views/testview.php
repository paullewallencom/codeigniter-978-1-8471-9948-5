<html>
   <head>
     <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
     <html xmlns='http://www.w3.org/1999/xhtml'>
     <title>Web test Site</title>
    
     <link rel="stylesheet" type="text/css" href="<?php echo $base."/".$css;?>">
   </head>
   <body>
     <h1><?php echo $mytitle; ?> </h1>
     <p class='test'> <?php echo $mytext; ?> </p>
   </body>
   </html>
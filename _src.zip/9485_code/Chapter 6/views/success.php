<?php

echo $this->session->flashdata('login');